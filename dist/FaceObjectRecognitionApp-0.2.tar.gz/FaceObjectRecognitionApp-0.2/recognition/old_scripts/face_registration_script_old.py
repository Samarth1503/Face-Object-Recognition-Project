# import cv2
# import os
# import sys
# import tkinter as tk
# from tkinter import Label, Button, Entry
# from PIL import Image, ImageTk
# import subprocess
# import os
# import face_recognition
# import pickle


# # Constants
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"

# # Function to update face encodings
# def process_new_faces():
#     """Processes new faces from the dataset and saves encodings to a file."""
#     print("[INFO] Processing new faces...")
#     encodings, names = [], []
    
#     for folder_name in os.listdir(FACES_DIR):
#         folder_path = os.path.join(FACES_DIR, folder_name)
#         if os.path.isdir(folder_path):
#             for filename in os.listdir(folder_path):
#                 if filename.endswith((".jpg", ".png", ".jpeg")):
#                     img_path = os.path.join(folder_path, filename)
#                     try:
#                         image = face_recognition.load_image_file(img_path)
#                         encoding = face_recognition.face_encodings(image)
#                         if encoding:
#                             encodings.append(encoding[0])
#                             names.append(folder_name)
#                     except Exception as e:
#                         print(f"[ERROR] Could not process image {img_path}: {e}")
    
#     # Save encodings to file
#     os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
#     with open(ENCODINGS_FILE, "wb") as file:
#         pickle.dump({"encodings": encodings, "names": names}, file)
    
#     print(f"[INFO] Saved {len(encodings)} face encodings.")
#     return encodings, names


# class FaceRegistrationApp:
#     def __init__(self, root):
#         self.root = root
#         self.root.title("Face Registration")
#         self.root.geometry("800x600")

#         self.name_label = Label(root, text="Enter your name:", font=("Arial", 14))
#         self.name_label.pack(pady=10)

#         self.name_entry = Entry(root, font=("Arial", 14))
#         self.name_entry.pack(pady=5)

#         self.start_button = Button(root, text="Start Registration", command=self.start_registration, font=("Arial", 14))
#         self.start_button.pack(pady=10)

#         self.instruction_label = Label(root, text="", font=("Arial", 14))
#         self.instruction_label.pack(pady=10)

#         self.prompt_label = Label(root, text="", font=("Arial", 12), fg="blue")  # Prompt for "Press Enter"
#         self.prompt_label.pack(pady=5)

#         self.video_label = Label(root)
#         self.video_label.pack()

#         self.cap = None
#         self.instructions = [
#             "Look straight at the camera",
#             "Turn slightly to your left",
#             "Turn slightly to your right",
#             "Look up slightly",
#             "Look down slightly",
#             "Smile!"
#         ]
#         self.count = 0
#         self.save_path = ""

#         self.root.bind('<Return>', self.capture_image)

#     def start_registration(self):
#         self.name = self.name_entry.get()
#         if not self.name:
#             self.instruction_label.config(text="Please enter your name.")
#             return

#         self.save_path = os.path.join("data/faces", self.name)
#         os.makedirs(self.save_path, exist_ok=True)

#         self.cap = cv2.VideoCapture(0)
#         if not self.cap.isOpened():
#             self.instruction_label.config(text="Error: Could not access webcam.")
#             return

#         self.name_entry.pack_forget()
#         self.name_label.pack_forget()
#         self.start_button.pack_forget()

#         self.update_frame()

#     def update_frame(self):
#         ret, frame = self.cap.read()
#         if ret:
#             img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
#             imgtk = ImageTk.PhotoImage(image=img)
#             self.video_label.imgtk = imgtk
#             self.video_label.config(image=imgtk)
#             self.instruction_label.config(text=self.instructions[self.count])
#             self.prompt_label.config(text="Press Enter to capture picture")

#         if self.cap.isOpened():
#             self.root.after(10, self.update_frame)

#     def capture_image(self, event=None):
#         if self.cap and self.cap.isOpened():
#             ret, frame = self.cap.read()
#             if ret:
#                 file_path = os.path.join(self.save_path, f"{self.name}_{self.count + 1}.jpg")
#                 cv2.imwrite(file_path, frame)
#                 self.count += 1

#                 if self.count >= 6:
#                     self.cap.release()
#                     self.process_new_face_encodings()  # Call the function to update encodings
#                     self.show_completion_buttons()
#                 else:
#                     self.instruction_label.config(text=self.instructions[self.count])

#     def process_new_face_encodings(self):
#         """ Updates the known encodings after registering a new face. """
#         self.instruction_label.config(text="Updating face database...")
#         self.root.update()  # Force update UI before processing
#         process_new_faces()  # Call function from processing_faces.py
#         self.instruction_label.config(text="Face database updated successfully!")

#     def show_completion_buttons(self):
#         self.instruction_label.config(text="Face Registration Completed!")
#         self.prompt_label.config(text="")  # Remove "Press Enter" prompt

#         return_button = Button(self.root, text="Return To App", command=self.return_to_app, font=("Arial", 14))
#         return_button.pack(pady=10)

#         new_face_button = Button(self.root, text="Register New Face", command=self.reset_registration, font=("Arial", 14))
#         new_face_button.pack(pady=10)

#     def return_to_app(self):
#         self.root.destroy()
#         subprocess.run(["python", "gui/app.py"])  # Ensure this path is correct

#     def reset_registration(self):
#         self.count = 0
#         self.instruction_label.config(text="")
#         self.prompt_label.config(text="")
#         self.video_label.config(image="")
#         self.name_entry.pack(pady=5)
#         self.name_label.pack(pady=10)
#         self.start_button.pack(pady=10)

# if __name__ == "__main__":
#     root = tk.Tk()
#     app = FaceRegistrationApp(root)
#     root.mainloop()

















# import cv2
# import os
# import sys
# import tkinter as tk
# from tkinter import Label, Button, Entry
# from PIL import Image, ImageTk
# import pickle
# import face_recognition

# # Constants
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"

# # Get camera index from command-line arguments
# camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# # Shared camera instance
# cap = cv2.VideoCapture(camera_index)
# if not cap.isOpened():
#     print("[ERROR] Cannot access webcam.")
#     sys.exit()

# print("[INFO] Using shared camera for face registration.")


# def process_new_faces():
#     """Processes new faces from the dataset and saves encodings to a file."""
#     print("[INFO] Processing new faces...")
#     encodings, names = [], []

#     for folder_name in os.listdir(FACES_DIR):
#         folder_path = os.path.join(FACES_DIR, folder_name)
#         if os.path.isdir(folder_path):
#             for filename in os.listdir(folder_path):
#                 if filename.endswith((".jpg", ".png", ".jpeg")):
#                     img_path = os.path.join(folder_path, filename)
#                     try:
#                         image = face_recognition.load_image_file(img_path)
#                         encoding = face_recognition.face_encodings(image)
#                         if not encoding:
#                             print(f"[WARNING] No face found in {img_path}, skipping...")
#                             continue  # Skip images without detected faces
#                         encodings.append(encoding[0])
#                         names.append(folder_name)
#                     except Exception as e:
#                         print(f"[ERROR] Could not process image {img_path}: {e}")

#     # Save encodings to file
#     os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
#     with open(ENCODINGS_FILE, "wb") as file:
#         pickle.dump({"encodings": encodings, "names": names}, file)

#     print(f"[INFO] Saved {len(encodings)} face encodings.")
#     return encodings, names


# class FaceRegistrationApp:
#     def __init__(self, root):
#         self.root = root
#         self.root.title("Face Registration")
#         self.root.geometry("800x600")

#         self.name_label = Label(root, text="Enter your name:", font=("Arial", 14))
#         self.name_label.pack(pady=10)

#         self.name_entry = Entry(root, font=("Arial", 14))
#         self.name_entry.pack(pady=5)

#         self.start_button = Button(root, text="Start Registration", command=self.start_registration, font=("Arial", 14))
#         self.start_button.pack(pady=10)

#         self.instruction_label = Label(root, text="", font=("Arial", 14))
#         self.instruction_label.pack(pady=10)

#         self.prompt_label = Label(root, text="", font=("Arial", 12), fg="blue")  # Prompt for "Press Enter"
#         self.prompt_label.pack(pady=5)

#         self.video_label = Label(root)
#         self.video_label.pack()

#         self.cap = cap  # Use shared camera instance
#         self.instructions = [
#             "Look straight at the camera",
#             "Turn slightly to your left",
#             "Turn slightly to your right",
#             "Look up slightly",
#             "Look down slightly",
#             "Smile!"
#         ]
#         self.count = 0
#         self.save_path = ""

#         self.root.bind('<Return>', self.capture_image)

#     def start_registration(self):
#         """Starts face registration and initializes webcam feed."""
#         self.name = self.name_entry.get()
#         if not self.name:
#             self.instruction_label.config(text="Please enter your name.")
#             return

#         self.save_path = os.path.join(FACES_DIR, self.name)
#         os.makedirs(self.save_path, exist_ok=True)

#         # Hide entry and start button
#         self.name_entry.pack_forget()
#         self.name_label.pack_forget()
#         self.start_button.pack_forget()

#         self.update_frame()

#     def update_frame(self):
#         """Continuously updates the video feed in the UI."""
#         ret, frame = self.cap.read()
#         if ret:
#             img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
#             imgtk = ImageTk.PhotoImage(image=img)
#             self.video_label.imgtk = imgtk
#             self.video_label.config(image=imgtk)
#             self.instruction_label.config(text=self.instructions[self.count])
#             self.prompt_label.config(text="Press Enter to capture picture")

#         if self.cap.isOpened():
#             self.root.after(10, self.update_frame)

#     def capture_image(self, event=None):
#         """Captures the current frame and saves it as an image."""
#         if self.cap and self.cap.isOpened():
#             ret, frame = self.cap.read()
#             if ret:
#                 file_path = os.path.join(self.save_path, f"{self.name}_{self.count + 1}.jpg")
#                 cv2.imwrite(file_path, frame)
#                 self.count += 1

#                 if self.count >= 6:
#                     self.process_new_face_encodings()  # Call the function to update encodings
#                     self.show_completion_buttons()
#                 else:
#                     self.instruction_label.config(text=self.instructions[self.count])

#     def process_new_face_encodings(self):
#         """Updates the known encodings after registering a new face."""
#         self.instruction_label.config(text="Updating face database... Please wait.")
#         self.root.update()  # Force UI update before processing
#         process_new_faces()  # Call function to process faces
#         self.instruction_label.config(text="Face database updated successfully!")

#     def show_completion_buttons(self):
#         """Displays buttons for returning to the app or registering another face."""
#         self.instruction_label.config(text="Face Registration Completed!")
#         self.prompt_label.config(text="")  # Remove "Press Enter" prompt

#         return_button = Button(self.root, text="Return To App", command=self.return_to_app, font=("Arial", 14))
#         return_button.pack(pady=10)

#         new_face_button = Button(self.root, text="Register New Face", command=self.reset_registration, font=("Arial", 14))
#         new_face_button.pack(pady=10)

#     def return_to_app(self):
#         """Closes the registration window without launching a new instance."""
#         self.cap.release()  # Release camera when closing
#         cv2.destroyAllWindows()
#         self.root.destroy()  # Just close the window, don't relaunch the app

#     def reset_registration(self):
#         """Resets the registration UI for a new user."""
#         self.count = 0
#         self.instruction_label.config(text="")
#         self.prompt_label.config(text="")
#         self.video_label.config(image="")
#         self.name_entry.pack(pady=5)
#         self.name_label.pack(pady=10)
#         self.start_button.pack(pady=10)


# if __name__ == "__main__":
#     root = tk.Tk()
#     app = FaceRegistrationApp(root)
#     root.mainloop()






























# v_working_0.7 (CustomTkinter working)

# import cv2
# import os
# import sys
# import tkinter as tk
# from tkinter import Label, Button, Entry
# from PIL import Image, ImageTk
# import pickle
# import face_recognition
# import subprocess
# import customtkinter  # Ensure this import is correct
# import ttkbootstrap as ttk

# # Constants
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"
# CLOSE_IMAGE_PATH = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/fontsUsed/close.jpg"
# MAXIMIZE_IMAGE_PATH = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/fontsUsed/maximize.jpg"

# # Get camera index from command-line arguments
# camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# # Shared camera instance
# cap = cv2.VideoCapture(camera_index)
# if not cap.isOpened():
#     print("[ERROR] Cannot access webcam.")
#     sys.exit()

# print("[INFO] Using shared camera for face registration.")

# def process_new_faces():
#     """Processes new faces from the dataset and saves encodings to a file."""
#     print("[INFO] Processing new faces...")
#     encodings, names = [], []

#     for folder_name in os.listdir(FACES_DIR):
#         folder_path = os.path.join(FACES_DIR, folder_name)
#         if os.path.isdir(folder_path):
#             for filename in os.listdir(folder_path):
#                 if filename.endswith((".jpg", ".png", ".jpeg")):
#                     img_path = os.path.join(folder_path, filename)
#                     try:
#                         image = face_recognition.load_image_file(img_path)
#                         encoding = face_recognition.face_encodings(image)
#                         if not encoding:
#                             print(f"[WARNING] No face found in {img_path}, skipping...")
#                             continue  # Skip images without detected faces
#                         encodings.append(encoding[0])
#                         names.append(folder_name)
#                     except Exception as e:
#                         print(f"[ERROR] Could not process image {img_path}: {e}")

#     # Save encodings to file
#     os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
#     with open(ENCODINGS_FILE, "wb") as file:
#         pickle.dump({"encodings": encodings, "names": names}, file)

#     print(f"[INFO] Saved {len(encodings)} face encodings.")
#     return encodings, names

# def start_registration():
#     """Starts face registration and initializes webcam feed."""
#     global name, save_path, cap, count
#     name = name_entry.get()
#     if not name:
#         instruction_label.config(text="Please enter your name.")
#         return

#     save_path = os.path.join(FACES_DIR, name)
#     os.makedirs(save_path, exist_ok=True)

#     # Hide entry and start button
#     name_entry.pack_forget()
#     name_label.pack_forget()
#     start_button.pack_forget()

#     update_frame()

# def update_frame():
#     """Continuously updates the video feed in the UI."""
#     ret, frame = cap.read()
#     if ret:
#         img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
#         imgtk = ImageTk.PhotoImage(image=img)
#         video_label.imgtk = imgtk
#         video_label.config(image=imgtk)
#         instruction_label.config(text=instructions[count])
#         prompt_label.config(text="Press Enter to capture picture")

#     if cap.isOpened():
#         root.after(10, update_frame)

# def capture_image(event=None):
#     """Captures the current frame and saves it as an image."""
#     global count
#     if cap and cap.isOpened():
#         ret, frame = cap.read()
#         if ret:
#             file_path = os.path.join(save_path, f"{name}_{count + 1}.jpg")
#             cv2.imwrite(file_path, frame)
#             count += 1

#             if count >= 6:
#                 process_new_face_encodings()  # Call the function to update encodings
#                 show_completion_buttons()
#             else:
#                 instruction_label.config(text=instructions[count])

# def process_new_face_encodings():
#     """Updates the known encodings after registering a new face."""
#     instruction_label.config(text="Updating face database... Please wait.")
#     root.update()  # Force UI update before processing
#     process_new_faces()  # Call function to process faces
#     instruction_label.config(text="Face database updated successfully!")

# def show_completion_buttons():
#     """Displays buttons for returning to the app or registering another face."""
#     instruction_label.config(text="Face Registration Completed!")
#     prompt_label.config(text="")  # Remove "Press Enter" prompt

#     return_button = Button(root, text="Return To App", command=return_to_app, font=("Arial", 14))
#     return_button.pack(pady=10)

#     new_face_button = Button(root, text="Register New Face", command=reset_registration, font=("Arial", 14))
#     new_face_button.pack(pady=10)

# def return_to_app():
#     """Closes the registration window without launching a new instance."""
#     cap.release()  # Release camera when closing
#     cv2.destroyAllWindows()
#     root.destroy()  # Just close the window, don't relaunch the app

# def reset_registration():
#     """Resets the registration UI for a new user."""
#     global count
#     count = 0
#     instruction_label.config(text="")
#     prompt_label.config(text="")
#     video_label.config(image="")
#     name_entry.pack(pady=5)
#     name_label.pack(pady=10)
#     start_button.pack(pady=10)

# # Initialize Tkinter GUI with ttkbootstrap
# root = ttk.Window(themename="darkly")
# root.title("Face & Object Recognition App")
# root.geometry("600x400")
# root.configure(bg="#000000")

# # Remove the default title bar
# root.overrideredirect(True)

# # Create a custom title bar
# title_bar = tk.Frame(root, bg="#1A1A1A", relief='raised', bd=2, height=40)
# title_bar.pack(fill=tk.X)

# # Add title text to the custom title bar
# title_label = Label(title_bar, text="Face & Object Recognition App", font=("Urbanist-Thin", 14), fg="#C8C8F2", bg="#1A1A1A")
# title_label.pack(side=tk.LEFT, padx=10)

# # Load images for the buttons
# close_image = Image.open(CLOSE_IMAGE_PATH)
# maximize_image = Image.open(MAXIMIZE_IMAGE_PATH)

# close_image = close_image.resize((20, 20), Image.Resampling.LANCZOS)
# maximize_image = maximize_image.resize((20, 20), Image.Resampling.LANCZOS)

# close_image_tk = ImageTk.PhotoImage(close_image)
# maximize_image_tk = ImageTk.PhotoImage(maximize_image)

# # Function to close the window
# def close_window():
#     root.destroy()

# # Function to maximize the window
# def maximize_window():
#     root.overrideredirect(False)
#     if root.attributes('-fullscreen'):            \
#         root.attributes('-fullscreen', False)
#     else:
#         root.attributes('-fullscreen', True)        
#     root.overrideredirect(True)


# # Add maximize and close buttons to the custom title bar
# close_button = tk.Button(title_bar, image=close_image_tk, command=close_window, bg="#1A1A1A", fg="#C8C8F2", relief='flat', activebackground="#1A1A1A")
# close_button.pack(side=tk.RIGHT)

# maximize_button = tk.Button(title_bar, image=maximize_image_tk, command=maximize_window, bg="#1A1A1A", fg="#C8C8F2", relief='flat', activebackground="#1A1A1A")
# maximize_button.pack(side=tk.RIGHT)

# # Function to move the window
# def move_window(event):
#     root.geometry(f'+{event.x_root}+{event.y_root}')

# # Bind the title bar to the move function
# title_bar.bind('<B1-Motion>', move_window)

# # Add title text above buttons
# title_label = Label(root, text="Face Registration App", font=("Urbanist-Thin", 20), bg="#000000", fg="#D0BCFF")
# title_label.pack(pady=(25, 25))  # Add margin at the top

# name_label = Label(root, text="Enter your name:", font=("Arial", 14))
# name_label.pack(pady=10)

# name_entry = Entry(root, font=("Arial", 14))
# name_entry.pack(pady=5)

# start_button = Button(root, text="Start Registration", command=start_registration, font=("Arial", 14))
# start_button.pack(pady=10)

# instruction_label = Label(root, text="", font=("Arial", 14))
# instruction_label.pack(pady=10)

# prompt_label = Label(root, text="", font=("Arial", 12), fg="blue")  # Prompt for "Press Enter"
# prompt_label.pack(pady=5)

# video_label = Label(root)
# video_label.pack()

# instructions = [
#     "Look straight at the camera",
#     "Turn slightly to your left",
#     "Turn slightly to your right",
#     "Look up slightly",
#     "Look down slightly",
#     "Smile!"
# ]
# count = 0
# save_path = ""

# root.bind('<Return>', capture_image)

# if __name__ == "__main__":
#     root.mainloop() 


































# v_working_0.8 (Using GUI_LAYOUT.PY)

# import cv2
# import os
# import sys
# import tkinter as tk
# from tkinter import Label, Button, Entry
# from PIL import Image, ImageTk
# import pickle
# import face_recognition
# import subprocess
# import customtkinter
# import ttkbootstrap as ttk
# from gui.gui_layout import apply_gui_layout

# # Constants
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"
# IMAGE_PATH = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/fontsUsed/skull_2.png"

# # Get camera index from command-line arguments
# camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# # Shared camera instance
# cap = cv2.VideoCapture(camera_index)
# if not cap.isOpened():
#     print("[ERROR] Cannot access webcam.")
#     sys.exit()

# print("[INFO] Using shared camera for face registration.")

# def process_new_faces():
#     """Processes new faces from the dataset and saves encodings to a file."""
#     print("[INFO] Processing new faces...")
#     encodings, names = [], []

#     for folder_name in os.listdir(FACES_DIR):
#         folder_path = os.path.join(FACES_DIR, folder_name)
#         if os.path.isdir(folder_path):
#             for filename in os.listdir(folder_path):
#                 if filename.endswith((".jpg", ".png", ".jpeg")):
#                     img_path = os.path.join(folder_path, filename)
#                     try:
#                         image = face_recognition.load_image_file(img_path)
#                         encoding = face_recognition.face_encodings(image)
#                         if not encoding:
#                             print(f"[WARNING] No face found in {img_path}, skipping...")
#                             continue  # Skip images without detected faces
#                         encodings.append(encoding[0])
#                         names.append(folder_name)
#                     except Exception as e:
#                         print(f"[ERROR] Could not process image {img_path}: {e}")

#     # Save encodings to file
#     os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
#     with open(ENCODINGS_FILE, "wb") as file:
#         pickle.dump({"encodings": encodings, "names": names}, file)

#     print(f"[INFO] Saved {len(encodings)} face encodings.")
#     return encodings, names

# def start_registration():
#     """Starts face registration and initializes webcam feed."""
#     global name, save_path, cap, count
#     name = name_entry.get()
#     if not name:
#         instruction_label.config(text="Please enter your name.")
#         return

#     save_path = os.path.join(FACES_DIR, name)
#     os.makedirs(save_path, exist_ok=True)

#     # Hide entry and start button
#     name_entry.pack_forget()
#     name_label.pack_forget()
#     start_button.pack_forget()

#     # Resize and center the window
#     root.geometry("1000x800")
#     root.update_idletasks()
#     width = root.winfo_width()
#     height = root.winfo_height()
#     x = (root.winfo_screenwidth() // 2) - (width // 2)
#     y = (root.winfo_screenheight() // 2) - (height // 2)
#     root.geometry(f'{width}x{height}+{x}+{y}')

#     update_frame()

# def update_frame():
#     """Continuously updates the video feed in the UI."""
#     ret, frame = cap.read()
#     if ret:
#         img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
#         imgtk = ImageTk.PhotoImage(image=img)
#         video_label.imgtk = imgtk
#         video_label.config(image=imgtk)
#         instruction_label.config(text=instructions[count])
#         prompt_label.config(text="Press Enter to capture picture")

#     if cap.isOpened():
#         root.after(10, update_frame)

# def capture_image(event=None):
#     """Captures the current frame and saves it as an image."""
#     global count
#     if cap and cap.isOpened():
#         ret, frame = cap.read()
#         if ret:
#             file_path = os.path.join(save_path, f"{name}_{count + 1}.jpg")
#             cv2.imwrite(file_path, frame)
#             count += 1

#             if count >= 6:
#                 process_new_face_encodings()  # Call the function to update encodings
#                 show_completion_buttons()
#             else:
#                 instruction_label.config(text=instructions[count])

# def process_new_face_encodings():
#     """Updates the known encodings after registering a new face."""
#     instruction_label.config(text="Updating face database... Please wait.")
#     root.update()  # Force UI update before processing
#     process_new_faces()  # Call function to process faces
#     instruction_label.config(text="Face database updated successfully!")

# def show_completion_buttons():
#     """Displays buttons for returning to the app or registering another face."""
#     instruction_label.config(text="Face Registration Completed!")
#     prompt_label.config(text="")  # Remove "Press Enter" prompt

#     return_button = Button(root, text="Return To App", command=return_to_app, font=("Arial", 14))
#     return_button.pack(pady=10)

#     new_face_button = Button(root, text="Register New Face", command=reset_registration, font=("Arial", 14))
#     new_face_button.pack(pady=10)

# def return_to_app():
#     """Closes the registration window without launching a new instance."""
#     cap.release()  # Release camera when closing
#     cv2.destroyAllWindows()
#     root.destroy()  # Just close the window, don't relaunch the app

# def reset_registration():
#     """Resets the registration UI for a new user."""
#     global count
#     count = 0
#     instruction_label.config(text="")
#     prompt_label.config(text="")
#     video_label.config(image="")
#     name_entry.pack(pady=5)
#     name_label.pack(pady=10)
#     start_button.pack(pady=10)

# # Initialize Tkinter GUI with ttkbootstrap
# root = ttk.Window(themename="darkly")

# # Apply the GUI layout
# title_bar, title_label = apply_gui_layout(
#     root, "Face & Object Recognition App", "600x400", "#000000", ("Urbanist-Thin", 14),
#     "#000000", "#C8C8F2", "#C8C8F2", "#2a2633", "#1A1A1A", "#C8C8F2", "#D0BCFF"
# )

# # Add title text above buttons
# title_label = Label(root, text="Face Registration App", font=("Urbanist-Thin", 20), bg="#000000", fg="#D0BCFF")
# title_label.pack(pady=(25, 25))  # Add margin at the top

# name_label = Label(root, text="Enter your name:", font=("Arial", 14))
# name_label.pack(pady=10)

# name_entry = Entry(root, font=("Arial", 14))
# name_entry.pack(pady=5)

# start_button = Button(root, text="Start Registration", command=start_registration, font=("Arial", 14))
# start_button.pack(pady=10)

# instruction_label = Label(root, text="", font=("Arial", 14))
# instruction_label.pack(pady=10)

# prompt_label = Label(root, text="", font=("Arial", 12), fg="blue")  # Prompt for "Press Enter"
# prompt_label.pack(pady=5)

# video_label = Label(root)
# video_label.pack()

# # Add image at the bottom right
# image = Image.open(IMAGE_PATH)
# image = image.resize((100, 100), Image.Resampling.LANCZOS)
# image_tk = ImageTk.PhotoImage(image)
# image_label = Label(root, image=image_tk, bg="#000000")
# image_label.image = image_tk  # Keep a reference to avoid garbage collection
# image_label.place(relx=1.0, rely=1.0, anchor='se', x=-10, y=-10)  # Position at bottom right with some padding

# instructions = [
#     "Look straight at the camera",
#     "Turn slightly to your left",
#     "Turn slightly to your right",
#     "Look up slightly",
#     "Look down slightly",
#     "Smile!"
# ]
# count = 0
# save_path = ""

# root.bind('<Return>', capture_image)

# if __name__ == "__main__":
#     # Center the window on the screen
#     root.update_idletasks()
#     width = root.winfo_width()
#     height = root.winfo_height()
#     x = (root.winfo_screenwidth() // 2) - (width // 2)
#     y = (root.winfo_screenheight() // 2) - (height // 2)
#     root.geometry(f'{width}x{height}+{x}+{y}')
#     root.mainloop()