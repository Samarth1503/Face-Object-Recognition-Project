from setuptools import setup, find_packages

setup(
    name='FaceObjectRecognitionApp',
    version='0.2',
    packages=find_packages(),
    install_requires=[
        'pillow',
        'customtkinter',
        'ttkbootstrap',
        'opencv-python-headless',
        'face_recognition',
        'numpy'
    ],
    description='A face and object recognition application',
    author='Samarth Birdawade',
    author_email='sammehta063@gmail.com',
    url='https://github.com/Samarth1503/Face-Object-Recognition-Project',
)