from setuptools import setup, find_packages

setup(
    name='FaceObjectRecognitionApp',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        'Pillow',
        'customtkinter',
        'ttkbootstrap',
        'opencv-python',
        'face_recognition',
        'dlib',
        'opencv-contrib-python',
        'numpy'
    ],
    description='A face and recognition application',
    author='Samarth Birdawade',
    author_email='sammehta063@gmail.com',
    url='https://github.com/Samarth1503/FaceObjectRecognitionApp',
)