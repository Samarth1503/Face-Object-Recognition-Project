# v_Working_0.8

# import os
# import sys
# import cv2
# import face_recognition
# import numpy as np
# import threading
# import tkinter as tk
# from tkinter import Label
# from PIL import Image, ImageTk
# import pickle

# # Constants
# PROCESS_EVERY_N_FRAMES = 1  # Process every frame
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"

# # Get camera index from command-line arguments
# camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# # Function to load known face encodings and names
# def load_known_faces():
#     """Loads known face encodings and names from a file."""
#     if not os.path.exists(ENCODINGS_FILE):
#         print("[INFO] No saved encodings found. Returning empty lists.")
#         return [], []
    
#     with open(ENCODINGS_FILE, "rb") as file:
#         data = pickle.load(file)
    
#     print(f"[INFO] Loaded {len(data['encodings'])} known faces from file.")
#     return data["encodings"], data["names"]


# # Global variables
# running = True
# known_encodings, known_names = load_known_faces()
# frame_count = 0
# cap = None  # Single webcam instance
# recognized_face = {}  # Stores recognized faces and their coordinates
# recognized_face_colour = (188, 188, 242)  # Default color for face rectangle


# # Face Recognition GUI
# class FaceRecognitionApp:
#     def __init__(self):
#         global cap

#         self.root = tk.Tk()
#         self.root.title("Face Recognition")
#         self.root.protocol("WM_DELETE_WINDOW", self.on_close)
#         self.root.geometry("800x600")

#         self.canvas = tk.Label(self.root)
#         self.canvas.pack()

#         cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
#         if not cap.isOpened():
#             print("[ERROR] Cannot open webcam.")
#             self.root.destroy()
#             return

#         cap.set(cv2.CAP_PROP_FPS, 30)
#         cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
#         cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

#         self.update_feed()

#     def update_feed(self):
#         global cap, frame_count

#         if not cap.isOpened() or not running:
#             return

#         ret, frame = cap.read()
#         if not ret:
#             return

#         frame_count += 1
#         if frame_count % PROCESS_EVERY_N_FRAMES == 0:
#             frame = self.recognize_faces(frame)

#         self.update_frame(frame)
#         self.root.after(10, self.update_feed)

#     def recognize_faces(self, frame):
#         global recognized_face, recognized_face_colour

#         small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
#         rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

#         face_locations = face_recognition.face_locations(rgb_small_frame, model='hog')
#         face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

#         for encoding, (top, right, bottom, left) in zip(face_encodings, face_locations):
#             matches = face_recognition.compare_faces(known_encodings, encoding, tolerance=0.4)
#             name = "Unknown"

#             if True in matches:
#                 match_index = np.argmin(face_recognition.face_distance(known_encodings, encoding))
#                 name = known_names[match_index]

#             # Scale coordinates back to original size
#             top, right, bottom, left = [v * 4 for v in (top, right, bottom, left)]
            
#             # Store recognized face data
#             recognized_face[name] = {"coordinates": (left, top, right, bottom)}

#             cv2.rectangle(frame, (left, top), (right, bottom), recognized_face_colour, 2)
#             cv2.putText(frame, f"{name}", (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, recognized_face_colour, 2)

#         return frame

#     def update_frame(self, frame):
#         frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#         img = Image.fromarray(frame_rgb)
#         img = img.resize((800, 600))
#         img_tk = ImageTk.PhotoImage(image=img)

#         self.canvas.img_tk = img_tk
#         self.canvas.configure(image=img_tk)

#     def on_close(self):
#         global running, cap
#         running = False
#         if cap:
#             cap.release()
#         self.root.quit()

#     def run(self):
#         self.root.mainloop()

# # Start the application
# if __name__ == "__main__":
#     app = FaceRecognitionApp()
#     app.run()

#     running = False
#     print("[INFO] Application closed.")
























# v_Working_0.9

# import os
# import sys
# import cv2
# import face_recognition
# import numpy as np
# import threading
# import tkinter as tk
# from tkinter import Label
# from PIL import Image, ImageTk
# import pickle

# # Constants
# PROCESS_EVERY_N_FRAMES = 5 # Process every 3rd frame
# FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
# ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"

# # Get camera index from command-line arguments
# camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# # Load known faces
# def load_known_faces():
#     if not os.path.exists(ENCODINGS_FILE):
#         print("[INFO] No saved encodings found. Returning empty lists.")
#         return [], []
#     with open(ENCODINGS_FILE, "rb") as file:
#         data = pickle.load(file)
#     print(f"[INFO] Loaded {len(data['encodings'])} known faces from file.")
#     return data["encodings"], data["names"]

# # Global Variables
# running = True
# known_encodings, known_names = load_known_faces()
# frame_count = 0
# cap = None  # Webcam instance
# recognized_face = {}  # Stores recognized faces
# recognized_face_lock = threading.Lock()  # Thread-safe lock
# recognized_face_colour = (255, 172, 166)  # Rectangle color

# # Face Recognition Class
# class FaceRecognitionApp:
#     def __init__(self):
#         global cap
        
#         self.root = tk.Tk()
#         self.root.title("Face Recognition")
#         self.root.protocol("WM_DELETE_WINDOW", self.on_close)
#         self.root.geometry("800x600")

#         self.canvas = tk.Label(self.root)
#         self.canvas.pack()

#         cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
#         if not cap.isOpened():
#             print("[ERROR] Cannot open webcam.")
#             self.root.destroy()
#             return

#         cap.set(cv2.CAP_PROP_FPS, 30)
#         cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
#         cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

#         threading.Thread(target=self.process_faces, daemon=True).start()
#         self.update_feed()
    
#     def process_faces(self):
#         """Threaded function to process Feed1 (Face Recognition)."""
#         global cap, frame_count, recognized_face
#         while running:
#             ret, frame = cap.read()
#             if not ret:
#                 continue

#             frame_count += 1
#             if frame_count % PROCESS_EVERY_N_FRAMES == 0:
#                 small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
#                 rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

#                 face_locations = face_recognition.face_locations(rgb_small_frame, model='hog')
#                 face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

#                 with recognized_face_lock:
#                     recognized_face.clear()  # Clear previous face data

#                     for encoding, (top, right, bottom, left) in zip(face_encodings, face_locations):
#                         matches = face_recognition.compare_faces(known_encodings, encoding, tolerance=0.4)
#                         name = "Unknown"

#                         if True in matches:
#                             match_index = np.argmin(face_recognition.face_distance(known_encodings, encoding))
#                             name = known_names[match_index]

#                         top, right, bottom, left = [v * 4 for v in (top, right, bottom, left)]
#                         recognized_face[name] = (left, top, right, bottom)
    
#     def update_feed(self):
#         """Continuously updates Feed2 (GUI Display) with smooth rendering."""
#         global cap

#         if not cap.isOpened() or not running:
#             return

#         ret, frame = cap.read()
#         if not ret:
#             return

#         # Draw face rectangles from Feed1 (Processed Feed) onto Feed2 (GUI Display)
#         with recognized_face_lock:
#             for name, (left, top, right, bottom) in recognized_face.items():
#                 cv2.rectangle(frame, (left, top), (right, bottom), recognized_face_colour, 2)
#                 cv2.putText(frame, f"{name}", (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, recognized_face_colour, 2)
        
#         self.update_frame(frame)
#         self.root.after(10, self.update_feed)

#     def update_frame(self, frame):
#         """Converts OpenCV frame to Tkinter-compatible format."""
#         frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#         img = Image.fromarray(frame_rgb)
#         img = img.resize((800, 600))
#         img_tk = ImageTk.PhotoImage(image=img)
        
#         self.canvas.img_tk = img_tk
#         self.canvas.configure(image=img_tk)
    
#     def on_close(self):
#         """Handles application closing properly."""
#         global running, cap
#         running = False
#         if cap:
#             cap.release()
#         self.root.quit()
    
#     def run(self):
#         """Starts the Tkinter GUI."""
#         self.root.mainloop()

# if __name__ == "__main__":
#     app = FaceRecognitionApp()
#     app.run()
#     running = False
#     print("[INFO] Application closed.")










































# v_working_1.0

import os
import sys
import cv2
import face_recognition
import numpy as np
import threading
import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk
import pickle
import customtkinter
import ttkbootstrap as ttk

# Constants
PROCESS_EVERY_N_FRAMES = 5  # Process every 5th frame
FACES_DIR = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/faces"
ENCODINGS_FILE = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/data/knownDatasetEncodings/encodings.pkl"

# Get camera index from command-line arguments
camera_index = int(sys.argv[1]) if len(sys.argv) > 1 else 0

# Load known faces
def load_known_faces():
    if not os.path.exists(ENCODINGS_FILE):
        print("[INFO] No saved encodings found. Returning empty lists.")
        return [], []
    with open(ENCODINGS_FILE, "rb") as file:
        data = pickle.load(file)
    print(f"[INFO] Loaded {len(data['encodings'])} known faces from file.")
    return data["encodings"], data["names"]

# Global Variables
running = True
known_encodings, known_names = load_known_faces()
frame_count = 0
cap = None  # Webcam instance
recognized_face = {}  # Stores recognized faces
recognized_face_lock = threading.Lock()  # Thread-safe lock
recognized_face_colour = (255, 172, 166)  # Rectangle color

# Face Recognition Class
class FaceRecognitionApp:
    def __init__(self):
        global cap
        
        # Apply modern UI styling
        title_label_text = "Face & Object Recognition App"
        window_size = "600x400"
        window_bg = "#000000"
        font_style = ("Urbanist-Thin", 14)
        button_bg = "#000000"  # Button background
        button_fg = "#C8C8F2"  # Light purple text
        button_border = "#C8C8F2"  # Light purple border
        button_hover_bg = "#2a2633"  # Darker hover effect
        title_bar_bg = "#1A1A1A"  # Title bar background color
        title_bar_fg = "#C8C8F2"  # Title bar font color
        title_bar_font_color = "#D0BCFF"  # Title bar font color

        # Initialize Tkinter GUI with ttkbootstrap
        self.root = ttk.Window(themename="darkly")
        self.root.title(title_label_text)
        self.root.geometry(window_size)
        self.root.configure(bg=window_bg)

        # Remove the default title bar
        self.root.overrideredirect(True)

        # Create a custom title bar
        title_bar = tk.Frame(self.root, bg=title_bar_bg, relief='raised', bd=2)
        title_bar.pack(fill=tk.X)

        # Add title text to the custom title bar
        title_label = Label(title_bar, text=title_label_text, font=("Urbanist-Thin", 10), fg=title_bar_fg, bg=title_bar_bg)
        title_label.pack(side=tk.LEFT, padx=10)

        # Load images for the buttons
        close_image_path = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/fontsUsed/close.jpg"
        minimize_image_path = "C:/Users/58008_Rock/Desktop/College/VU/FY Sem 2/Python/FaceObjectRecognitionApp/fontsUsed/minimize.jpg"

        close_image = Image.open(close_image_path)
        minimize_image = Image.open(minimize_image_path)

        close_image = close_image.resize((20, 20), Image.Resampling.LANCZOS)
        minimize_image = minimize_image.resize((20, 20), Image.Resampling.LANCZOS)

        close_image_tk = ImageTk.PhotoImage(close_image)
        minimize_image_tk = ImageTk.PhotoImage(minimize_image)

        # Function to close the window
        def close_window():
            self.root.destroy()

        # Function to minimize the window
        def minimize_window():
            self.root.overrideredirect(False)
            self.root.iconify()
            self.root.overrideredirect(True)

        # Add minimize and close buttons to the custom title bar
        close_button = tk.Button(title_bar, image=close_image_tk, command=close_window, bg=title_bar_bg, fg=title_bar_fg, relief='flat', activebackground=title_bar_bg)
        close_button.pack(side=tk.RIGHT)

        minimize_button = tk.Button(title_bar, image=minimize_image_tk, command=minimize_window, bg=title_bar_bg, fg=title_bar_fg, relief='flat', activebackground=title_bar_bg)
        minimize_button.pack(side=tk.RIGHT)

        # Function to move the window
        def move_window(event):
            self.root.geometry(f'+{event.x_root}+{event.y_root}')

        # Bind the title bar to the move function
        title_bar.bind('<B1-Motion>', move_window)

        # Add title text above buttons
        title_label = Label(self.root, text="Face Recognition App", font=("Urbanist-Thin", 20), bg=window_bg, fg=title_bar_font_color)
        title_label.pack(pady=(25, 25))  # Add margin at the top

        self.canvas = tk.Label(self.root)
        self.canvas.pack()

        cap = cv2.VideoCapture(camera_index, cv2.CAP_DSHOW)
        if not cap.isOpened():
            print("[ERROR] Cannot open webcam.")
            self.root.destroy()
            return

        cap.set(cv2.CAP_PROP_FPS, 30)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        threading.Thread(target=self.process_faces, daemon=True).start()
        self.update_feed()
    
    def process_faces(self):
        """Threaded function to process Feed1 (Face Recognition)."""
        global cap, frame_count, recognized_face
        while running:
            ret, frame = cap.read()
            if not ret:
                continue

            frame_count += 1
            if frame_count % PROCESS_EVERY_N_FRAMES == 0:
                small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
                rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

                face_locations = face_recognition.face_locations(rgb_small_frame, model='hog')
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                with recognized_face_lock:
                    recognized_face.clear()  # Clear previous face data

                    for encoding, (top, right, bottom, left) in zip(face_encodings, face_locations):
                        matches = face_recognition.compare_faces(known_encodings, encoding, tolerance=0.4)
                        name = "Unknown"

                        if True in matches:
                            match_index = np.argmin(face_recognition.face_distance(known_encodings, encoding))
                            name = known_names[match_index]

                        top, right, bottom, left = [v * 4 for v in (top, right, bottom, left)]
                        recognized_face[name] = (left, top, right, bottom)
    
    def update_feed(self):
        """Continuously updates Feed2 (GUI Display) with smooth rendering."""
        global cap

        if not cap.isOpened() or not running:
            return

        ret, frame = cap.read()
        if not ret:
            return

        # Draw face rectangles from Feed1 (Processed Feed) onto Feed2 (GUI Display)
        with recognized_face_lock:
            for name, (left, top, right, bottom) in recognized_face.items():
                cv2.rectangle(frame, (left, top), (right, bottom), recognized_face_colour, 2)
                cv2.putText(frame, f"{name}", (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, recognized_face_colour, 2)
        
        self.update_frame(frame)
        self.root.after(10, self.update_feed)

    def update_frame(self, frame):
        """Converts OpenCV frame to Tkinter-compatible format."""
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        img = img.resize((800, 600))
        img_tk = ImageTk.PhotoImage(image=img)
        
        self.canvas.img_tk = img_tk
        self.canvas.configure(image=img_tk)
    
    def on_close(self):
        """Handles application closing properly."""
        global running, cap
        running = False
        if cap:
            cap.release()
        self.root.quit()
    
    def run(self):
        """Starts the Tkinter GUI."""
        self.root.mainloop()

if __name__ == "__main__":
    app = FaceRecognitionApp()
    app.run()
    running = False
    print("[INFO] Application closed.")