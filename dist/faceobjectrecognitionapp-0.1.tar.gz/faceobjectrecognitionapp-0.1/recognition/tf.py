try:
    import customtkinter
    print("customtkinter is installed and accessible.")
except ImportError:
    print("customtkinter is not installed or cannot be accessed.")